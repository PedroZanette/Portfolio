package com.senai.biblio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiblioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiblioApplication.class, args);
                System.out.println("### Projeto da equipe: Frango Do G");
                System.out.println("### Participantes:  Pedro Zanette / Vitor Kurth / Gabriel / Rafael");
        }

}
